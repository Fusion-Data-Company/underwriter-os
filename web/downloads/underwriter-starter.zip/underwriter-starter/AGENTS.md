# Underwriter workspace

Read FIRM.json for workspace identity, then reference/rigor-standard.md and reference/underwriting-model.md. Use templates/sources.md to retain evidence with dates and distinguish observations, assumptions and calculations.

Start each engagement by completing onboarding/user-intake.md with the firm's actual objectives. Do not use example profiles as real people or assume a tool is connected because it is listed in catalog/TOOL-CATALOG.md. Check the current runtime's available tools before choosing a workflow.

The playbooks under plugins/underwriter-os/skills are reference instructions. Claude-specific commands are not executable Codex integrations; use only available, authorized equivalents and state any missing capability. Do not install connectors, send messages, incur costs or change external records merely because a playbook suggests it. Follow the firm's explicit authorization.

Keep deal work under deals/, with separate source evidence and derived analysis. Never invent market data, identify sample output as real, or describe an unverified deal as investment-ready. Preserve source artifacts and log material assumptions. Optional voice and data providers require the firm's own configured access.
